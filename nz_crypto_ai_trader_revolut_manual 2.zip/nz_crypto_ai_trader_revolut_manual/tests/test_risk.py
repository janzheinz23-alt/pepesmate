from src.risk import evaluate_trade

def test_xrp_example_rejected_after_costs():
    p = evaluate_trade("XRP", 100, 1.94, .015, .03, .0099, 0, .002)
    assert not p.approved_by_rules
    assert p.net_reward_nzd < 0
    assert p.net_risk_nzd > 1.50

def test_invalid_entry_rejected():
    try:
        evaluate_trade("XRP", 100, 0, .015, .03, .0099, 0, .002)
    except ValueError:
        return
    assert False, "Expected invalid entry to raise"
