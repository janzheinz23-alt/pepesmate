from dataclasses import dataclass

@dataclass(frozen=True)
class TradePlan:
    symbol: str
    quantity: float
    stop_nzd: float
    target_nzd: float
    fees_nzd: float
    net_reward_nzd: float
    net_risk_nzd: float
    net_rr: float
    approved_by_rules: bool
    reasons: tuple[str, ...]

def evaluate_trade(symbol, capital_nzd, entry_nzd, stop_pct, target_pct,
                   fee_rate, min_fee_nzd, round_trip_friction_pct,
                   max_risk_nzd=1.50, daily_loss_limit_nzd=3.0,
                   min_net_rr=2.0):
    if min(capital_nzd, entry_nzd) <= 0:
        raise ValueError("Capital and entry must be positive.")
    if not (0 < stop_pct < 1) or target_pct <= 0:
        raise ValueError("Invalid stop/target percentage.")
    if min(fee_rate, min_fee_nzd, round_trip_friction_pct) < 0:
        raise ValueError("Costs cannot be negative.")
    qty = capital_nzd / entry_nzd
    stop = entry_nzd * (1 - stop_pct)
    target = entry_nzd * (1 + target_pct)
    buy_fee = max(capital_nzd * fee_rate, min_fee_nzd)
    target_value, stop_value = qty * target, qty * stop
    sell_fee_target = max(target_value * fee_rate, min_fee_nzd)
    sell_fee_stop = max(stop_value * fee_rate, min_fee_nzd)
    friction = capital_nzd * round_trip_friction_pct
    reward = target_value - capital_nzd - buy_fee - sell_fee_target - friction
    risk = capital_nzd - stop_value + buy_fee + sell_fee_stop + friction
    rr = reward / risk if risk > 0 else 0
    reasons = []
    if reward <= 0:
        reasons.append("Target does not produce a positive net return after costs.")
    if risk > max_risk_nzd:
        reasons.append(f"Net stop risk NZ${risk:.2f} exceeds NZ${max_risk_nzd:.2f} cap.")
    if risk > daily_loss_limit_nzd:
        reasons.append(f"Net stop risk exceeds daily loss limit NZ${daily_loss_limit_nzd:.2f}.")
    if rr < min_net_rr:
        reasons.append(f"Net reward/risk {rr:.2f}:1 is below {min_net_rr:.2f}:1.")
    return TradePlan(symbol, qty, stop, target, buy_fee + sell_fee_target,
                     reward, risk, rr, not reasons, tuple(reasons))
