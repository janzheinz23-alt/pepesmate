import argparse, json, sqlite3
from pathlib import Path
from datetime import datetime, timezone
from .risk import evaluate_trade

DB = "paper_trades.sqlite3"

def record_paper(plan, entry):
    with sqlite3.connect(DB) as con:
        con.execute(
            "CREATE TABLE IF NOT EXISTS paper_trades "
            "(created_at TEXT, symbol TEXT, entry_nzd REAL, stop_nzd REAL, "
            "target_nzd REAL, quantity REAL, status TEXT)"
        )
        con.execute("INSERT INTO paper_trades VALUES (?,?,?,?,?,?,?)", (
            datetime.now(timezone.utc).isoformat(), plan.symbol, entry,
            plan.stop_nzd, plan.target_nzd, plan.quantity, "PAPER_APPROVED"))

def main():
    p = argparse.ArgumentParser(description="Evaluate a manually quoted Revolut trade")
    p.add_argument("--symbol", required=True)
    p.add_argument("--capital", type=float, default=100.0)
    p.add_argument("--entry-nzd", type=float, required=True)
    p.add_argument("--stop-pct", type=float, default=0.015)
    p.add_argument("--target-pct", type=float, default=0.03)
    p.add_argument("--fee-rate", type=float, default=0.0099)
    p.add_argument("--min-fee-nzd", type=float, default=0.0)
    p.add_argument("--round-trip-friction-pct", type=float, default=0.002)
    p.add_argument("--record-paper", action="store_true")
    a = p.parse_args()
    cfg = json.loads(Path("config.json").read_text())
    plan = evaluate_trade(a.symbol, a.capital, a.entry_nzd, a.stop_pct,
        a.target_pct, a.fee_rate, a.min_fee_nzd, a.round_trip_friction_pct,
        cfg["max_risk_nzd"], cfg["daily_loss_limit_nzd"], cfg["min_net_reward_risk"])
    print(f"TRADE REVIEW — {plan.symbol}")
    print(f"Entry NZ${a.entry_nzd:.6f} | Stop NZ${plan.stop_nzd:.6f} | Target NZ${plan.target_nzd:.6f}")
    print(f"Estimated quantity: {plan.quantity:.8f}")
    print(f"Estimated round-trip fees: NZ${plan.fees_nzd:.2f}")
    print(f"Estimated net target result: NZ${plan.net_reward_nzd:.2f}")
    print(f"Estimated net stop loss: -NZ${plan.net_risk_nzd:.2f}")
    print(f"Net reward/risk: {plan.net_rr:.2f}:1")
    print("RULE CHECK:", "PASS — MANUAL REVIEW ONLY" if plan.approved_by_rules else "REJECT")
    for reason in plan.reasons:
        print(" -", reason)
    if not plan.approved_by_rules:
        return
    print("\nA PASS does not place an order. Verify exact Revolut quote and fees.")
    if a.record_paper:
        answer = input("Record as PAPER simulation only? Type PAPER: ").strip()
        if answer == "PAPER":
            record_paper(plan, a.entry_nzd)
            print("Paper simulation recorded. No real order was placed.")
        else:
            print("Not recorded.")

if __name__ == "__main__":
    main()
