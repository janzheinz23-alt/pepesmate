import pandas as pd

def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    required = {"open", "high", "low", "close", "volume"}
    if not required.issubset(df.columns):
        raise ValueError(f"Missing OHLCV columns: {required - set(df.columns)}")
    out = df.copy()
    close = out["close"]
    out["ema_9"] = close.ewm(span=9, adjust=False).mean()
    out["ema_21"] = close.ewm(span=21, adjust=False).mean()
    out["ema_50"] = close.ewm(span=50, adjust=False).mean()
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/14, adjust=False).mean()
    rs = gain / loss.replace(0, float("nan"))
    out["rsi_14"] = 100 - (100 / (1 + rs))
    fast = close.ewm(span=12, adjust=False).mean()
    slow = close.ewm(span=26, adjust=False).mean()
    out["macd"] = fast - slow
    out["macd_signal"] = out["macd"].ewm(span=9, adjust=False).mean()
    out["volume_sma_20"] = out["volume"].rolling(20).mean()
    out["atr_14"] = (out["high"] - out["low"]).rolling(14).mean()
    return out

def classify_latest(row):
    checks = {
        "price_above_ema21": row["close"] > row["ema_21"],
        "ema21_above_ema50": row["ema_21"] > row["ema_50"],
        "macd_bullish": row["macd"] > row["macd_signal"],
        "rsi_healthy": 45 <= row["rsi_14"] <= 68,
        "volume_confirming": row["volume_sma_20"] > 0 and row["volume"] > row["volume_sma_20"],
    }
    status = "WATCH" if sum(bool(v) for v in checks.values()) >= 4 else "NO TRADE"
    return status, checks
