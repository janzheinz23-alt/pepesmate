import argparse, json
from pathlib import Path
from .market_data import fetch_candles
from .indicators import add_indicators, classify_latest

def main():
    parser = argparse.ArgumentParser(description="Public-data crypto market scanner")
    parser.add_argument("--timeframe")
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()
    cfg = json.loads(Path("config.json").read_text())
    timeframe = args.timeframe or cfg["timeframe"]
    limit = args.limit or cfg["candle_limit"]
    print(f"PUBLIC MARKET SCAN | {cfg['exchange']} | {timeframe}")
    print("Signals are screening alerts, not trade recommendations.\n")
    for symbol in cfg["symbols"]:
        try:
            df = add_indicators(fetch_candles(cfg["exchange"], symbol, timeframe, limit))
            row = df.iloc[-1]
            status, checks = classify_latest(row)
            passed = ", ".join(k for k, v in checks.items() if v) or "none"
            ratio = row["volume"] / row["volume_sma_20"] if row["volume_sma_20"] else 0
            print(f"{symbol:10} {status:9} close={row['close']:.8g} "
                  f"RSI={row['rsi_14']:.1f} MACD={row['macd']:.6g} "
                  f"volume/avg={ratio:.2f}x checks={passed}")
        except Exception as exc:
            print(f"{symbol:10} UNAVAILABLE — {exc}")
    print("\nCompare all signals with your live Revolut NZD quote before evaluating a trade.")

if __name__ == "__main__":
    main()
