import ccxt
import pandas as pd

def fetch_candles(exchange_id: str, symbol: str, timeframe: str, limit: int):
    exchange_class = getattr(ccxt, exchange_id, None)
    if exchange_class is None:
        raise ValueError(f"Unsupported CCXT exchange: {exchange_id}")
    exchange = exchange_class({"enableRateLimit": True})
    if not exchange.has.get("fetchOHLCV"):
        raise RuntimeError(f"{exchange_id} does not support OHLCV")
    rows = exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    if not rows:
        raise RuntimeError(f"No candles returned for {symbol}")
    return pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close", "volume"])
