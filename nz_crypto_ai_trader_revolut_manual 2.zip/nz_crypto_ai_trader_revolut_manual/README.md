# NZ Crypto AI Trader — Revolut manual execution edition

Python market scanner and trade-decision assistant for a NZ$100 account.
It uses public market data and never connects to Revolut or places orders.
You manually execute any trade in the normal Revolut app.

## Included
- Public OHLCV candles from Kraken via CCXT (no account or API key).
- EMA 9/21/50, RSI 14, MACD, relative volume and ATR.
- Watchlist scanner for XRP, BTC, ETH, SOL and LINK.
- Fee-, spread- and slippage-aware NZD trade evaluator using the exact quote you enter.
- Manual confirmation to record a paper simulation only.
- Risk defaults: NZ$1.50 max planned risk, NZ$3 daily loss cap,
  one open position, 2:1 minimum net reward/risk, no leverage.

## Important
A PASS is for manual review only. It is not an instruction to buy.
Check the current Revolut buy/sell quote, fee, spread and order availability yourself.
This program does not submit orders. Revolut X is unavailable to this user, and the
ordinary Revolut app is treated as manual-only.

## Install (Python 3.11+)
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Scan public markets
```bash
python -m src.scan
python -m src.scan --timeframe 5m --limit 200
```
If Kraken does not list a pair or returns no candles, the scanner reports it.
Market prices can differ from Revolut's executable NZD quote.

## Evaluate a Revolut quote
```bash
python -m src.trade --symbol XRP --capital 100 --entry-nzd 1.94 \
  --stop-pct 0.015 --target-pct 0.03 \
  --fee-rate 0.0099 --min-fee-nzd 0 \
  --round-trip-friction-pct 0.002
```
Fee and friction inputs are illustrative. Replace them with the exact costs displayed
by Revolut. Do not assume Premium fees are always 0.99%.

To record a paper simulation after a rules PASS:
```bash
python -m src.trade --symbol XRP --entry-nzd 1.94 --record-paper
```
Type PAPER when prompted. This only records a simulation.

## Next steps
Run tests with `pytest`. Forward paper trade before risking real money.
Never paste passwords, recovery phrases, private keys or session cookies into this
project. Never enable withdrawals on any future API key.
